#!/bin/sh

rm -f dist/unix_setup/libexec/linux64/jaws
rm -f dist/unix_setup/libexec/linux32/jaws
rm -f dist/unix_setup/module/linux64/*.so
rm -f dist/unix_setup/module/linux32/*.so
rm -f dist/unix_setup/plugin/linux64/*.so
rm -f dist/unix_setup/plugin/linux32/*.so
